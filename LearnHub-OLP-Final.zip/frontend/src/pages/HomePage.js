
import React from 'react';
const HomePage = () => {
  return (
    <div>
      <h1>Welcome to LearnHub</h1>
      <p>Learn and Grow at your own pace!</p>
    </div>
  );
};
export default HomePage;
